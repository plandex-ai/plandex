package version

// Version will be set at build time using -ldflags
var Version = "development"
