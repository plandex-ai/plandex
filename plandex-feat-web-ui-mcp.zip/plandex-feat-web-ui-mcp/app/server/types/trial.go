package types

const TrialMaxReplies = 20
const TrialMaxPlans = 10
