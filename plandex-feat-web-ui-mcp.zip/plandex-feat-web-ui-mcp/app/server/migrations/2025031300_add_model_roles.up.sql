ALTER TABLE model_sets ADD COLUMN context_loader JSON;
ALTER TABLE model_sets ADD COLUMN whole_file_builder JSON;
ALTER TABLE model_sets ADD COLUMN coder JSON;