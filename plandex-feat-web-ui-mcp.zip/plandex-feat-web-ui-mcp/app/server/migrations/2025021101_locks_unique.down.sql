DROP TABLE IF EXISTS lockable_plan_ids;
DROP INDEX IF EXISTS repo_locks_single_write_lock;