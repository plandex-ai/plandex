DROP TABLE IF EXISTS model_sets;
DROP TABLE IF EXISTS custom_models;