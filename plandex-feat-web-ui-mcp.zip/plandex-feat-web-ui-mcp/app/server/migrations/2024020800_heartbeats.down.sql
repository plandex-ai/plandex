ALTER TABLE repo_locks DROP COLUMN last_heartbeat_at;
ALTER TABLE model_streams DROP COLUMN last_heartbeat_at;