ALTER TABLE custom_models DROP COLUMN max_output_tokens;
ALTER TABLE custom_models DROP COLUMN reserved_output_tokens;
ALTER TABLE custom_models DROP COLUMN model_id;
