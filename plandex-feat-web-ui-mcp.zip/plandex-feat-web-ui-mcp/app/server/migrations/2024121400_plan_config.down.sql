ALTER TABLE plans DROP COLUMN IF EXISTS plan_config;

ALTER TABLE users DROP COLUMN IF EXISTS default_plan_config;