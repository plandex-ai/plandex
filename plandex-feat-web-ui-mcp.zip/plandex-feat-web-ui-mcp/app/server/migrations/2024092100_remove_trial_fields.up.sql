ALTER TABLE auth_tokens DROP COLUMN is_trial;
ALTER TABLE users DROP COLUMN is_trial;