ALTER TABLE model_sets DROP COLUMN context_loader;
ALTER TABLE model_sets DROP COLUMN whole_file_builder;
ALTER TABLE model_sets DROP COLUMN coder;